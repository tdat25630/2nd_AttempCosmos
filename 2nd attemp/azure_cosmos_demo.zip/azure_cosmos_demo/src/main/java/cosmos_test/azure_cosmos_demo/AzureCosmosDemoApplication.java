package cosmos_test.azure_cosmos_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzureCosmosDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AzureCosmosDemoApplication.class, args);
	}

}
