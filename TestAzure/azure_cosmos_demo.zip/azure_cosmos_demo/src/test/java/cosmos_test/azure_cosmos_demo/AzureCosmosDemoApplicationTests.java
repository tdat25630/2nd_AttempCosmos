package cosmos_test.azure_cosmos_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzureCosmosDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
